const UsersModel = require('../models/UsersModel');

exports.createUser = async (req, res, next) => {
    try {
        let user = res.user !== undefined ? res.user : new UsersModel();
        const { userName } = req.body;
        user.userName = userName;
        await user.save();
        res.user = user;
        next();
    } catch (error) {
        console.log(error);
        res.status(500).json({message : error});
    }
}

exports.addGameBoard = async (req, res) => {
    try {
        let user = res.user;
        let game = res.game;
        user.games.push(game._id);
        await user.save();
        res.status(200).json(game);
    } catch (error) {
        console.log(error);
        res.status(500).json({message : error});
    }
}