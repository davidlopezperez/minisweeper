module.exports = class Player{

    static createNewUser(board, userName){
        board.player.userName = userName;
    }
}