module.exports = class Player{

    static createNewUser(board, user){
        board.player = user._id;
    }
}