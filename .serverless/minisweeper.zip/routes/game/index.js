const express = require('express');
const boardController = require('../../controllers/boardController');
const router = express.Router({
    mergeParams : true
});

router.post('/new', 
    boardController.createBoardAndStartGame
);

module.exports = router;