const UsersModel = require('../models/UsersModel');
module.exports = gamesByUsername = async (req, res, next) => {
    try {
        const { userName } = req.body;
        const games = await UsersModel.findOne({userName : userName}).populate({
            path : 'games',
            model : 'board'
        });
        res.games = games;
        games !== undefined ? (next()) : (res.status(200).json({message : 'Este jugador no tiene ninguna pártida'}));
    } catch (error) {
        console.log(error);
        res.status(500).json({message : error});
    }
}