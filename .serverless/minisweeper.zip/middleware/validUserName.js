const UsersModel = require('../models/UsersModel');
module.exports = validUserName = async (req, res, next) => {
    try {
        const { userName } = req.body;
        const user = await UsersModel.findOne({userName : userName});
        if(user){
            res.user = user;
        }
        return next();
    } catch (error) {
        console.log(error);
        res.status(500).json({message : 'Intenal Server Error'});
    }
}